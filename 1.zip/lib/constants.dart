import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF66344F);
const kP2rimaryColor = Color.fromARGB(255, 88, 31, 61);
const kPrimaryLightColor = Color(0xFFF1E6FF);

const double defaultPadding = 16.0;

const String spaceFont = 'SpaceFont';
const String headFont = 'poppins';

class Styles {
  // declare two fonts into separate varibales

// color pallate as per provided by neel
  final Color darkblueColor = HexColor('#100063');
  final Color blueColor = HexColor('#0037A7');
  final Color goldColor = HexColor('#FAD65A');

  final Color orangeColor = kP2rimaryColor;
  final Color pinkColor = kPrimaryColor;
  // color pallate as per provided by neel

  final Color tabJamunColor = HexColor('#6C2973');
  final Color tabOrangeColor = HexColor('#F38A5A');

  final Color tabdarkredColor = HexColor('#AA001A');
  final Color tabpinkColor = HexColor('#D6006F');

  final TextStyle buttonStyles = const TextStyle(
    fontFamily: headFont,
    fontWeight: FontWeight.normal,
    fontSize: 16,
    color: Colors.white,
  );

  // BUttons style
  final TextStyle btnStyle = const TextStyle(
    fontWeight: FontWeight.bold,
    fontSize: 20,
    color: Colors.black87,
  );
  final TextStyle appbarStyle = const TextStyle(
    fontFamily: headFont,
    fontSize: 13,
    color: Colors.white,
  );
}

class HexColor extends Color {
  static int _getColorFromHex(String hexColor) {
    hexColor = hexColor.toUpperCase().replaceAll("#", "");
    if (hexColor.length == 6) {
      hexColor = "FF" + hexColor;
    }
    return int.parse(hexColor, radix: 16);
  }

  HexColor(final String hexColor) : super(_getColorFromHex(hexColor));
}
