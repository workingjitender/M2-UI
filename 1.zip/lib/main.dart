import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

import 'Navigation.dart';
import 'constants.dart';
import 'pages/splash_screen.dart';

void main() {
  runApp(LoginUiApp());
}

class LoginUiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Astro Vardaan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Styles().pinkColor,
        accentColor: Styles().orangeColor,
        scaffoldBackgroundColor: Colors.grey.shade100,
        primarySwatch: Colors.grey,
      ),
      home: const SplashScreen(title: 'Welcome To Astro Vardaan'),
      //home: const NavBar(),
    );
  }
}
