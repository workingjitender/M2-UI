import 'package:flutter/material.dart';

import '../common/appBar.dart';
import '../constants.dart';

class SearchForm extends StatefulWidget {
  @override
  SearchFormState createState() => SearchFormState();
}

class SearchFormState extends State<SearchForm> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: BaseAppBar(
        title: Text(
          'Search Astrologers',
          style: Styles().appbarStyle,
        ),
        appBar: AppBar(),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(16),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                textAlignVertical: TextAlignVertical.center,
                autofocus: true,
                style: TextStyle(fontFamily: headFont, fontSize: 20),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  hintText: 'Search Astrologers',
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.search, color: Colors.white),
                  contentPadding: EdgeInsets.only(
                      left: 26.0, bottom: 8.0, top: 8.0, right: 50.0),
                ),
              ),
              alignment: Alignment.center,
            ),
          ),
        ],
      ),
    );
  }
}
