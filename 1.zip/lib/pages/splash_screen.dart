import 'package:easy_splash_screen/easy_splash_screen.dart';
import 'package:flutter/material.dart';
import 'login_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return EasySplashScreen(
      logo: Image.asset('assets/images/astro_logo.jpg'),
      logoWidth: 180,
      backgroundColor: const Color(0xFF66344F),
      showLoader: true,
      loadingText: Text(
        widget.title,
        style: TextStyle(color: Color(0xffffffff)),
      ),
      loaderColor: const Color(0xffffffff),
      navigator: LoginPage(),
      durationInSeconds: 5,
    );
  }
}
