import 'package:astro_app/constants.dart';
import 'package:flutter/material.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({Key? key}) : super(key: key);

  @override
  _WalletScreenState createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: kPrimaryColor,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 230,
              padding: EdgeInsets.all(40),
              child: Image.asset('assets/images/noBalance5.png'),
              decoration: BoxDecoration(
                  color: Color(0xFFF17650), shape: BoxShape.circle),
            ),
            const SizedBox(
              height: 40,
            ),
            const Text('No Balance!',
                style: TextStyle(fontSize: 20, color: Colors.white)),
            const SizedBox(
              height: 16,
            ),
            const Text(
              'Top Up your Wallet to avoid Intruption while comunicating with astrologers',
              style: TextStyle(fontSize: 15, color: Colors.white),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 32,
            ),
            FloatingActionButton(
              onPressed: () {
                print('Add Balance');
              },
              backgroundColor: Colors.white,
              child: Icon(Icons.add, size: 30, color: Colors.lightBlue),
            ),
          ],
        ),
      ),
    );
  }
}
