class City {
  //--- Name Of City
  final String name;
  //-- image
  final String image;
  //--- population
  final String population;
  //--- country
  final String country;

  City(
      {required this.name,
      required this.country,
      required this.population,
      required this.image});

  static List<City> allCities() {
    var lstOfCities = <City>[];

    lstOfCities.add(City(
        name: "Sagar Pandit",
        country: "Vedic, Numerology, Palmist",
        population: "7 Years",
        image:
            "https://www.citrix.com/blogs/wp-content/upload/2018/03/slack_compressed-e1521621363404-360x360.jpg"));

    lstOfCities.add(City(
        name: "Sagar Pandit",
        country: "Vedic, Numerology, Palmist",
        population: "7 Years",
        image:
            "https://www.citrix.com/blogs/wp-content/upload/2018/03/slack_compressed-e1521621363404-360x360.jpg"));

    lstOfCities.add(City(
        name: "Sagar Pandit",
        country: "Vedic, Numerology, Palmist",
        population: "7 Years",
        image:
            "https://www.citrix.com/blogs/wp-content/upload/2018/03/slack_compressed-e1521621363404-360x360.jpg"));

    lstOfCities.add(City(
        name: "Sagar Pandit",
        country: "Vedic, Numerology, Palmist",
        population: "7 Years",
        image:
            "https://www.citrix.com/blogs/wp-content/upload/2018/03/slack_compressed-e1521621363404-360x360.jpg"));

    lstOfCities.add(City(
        name: "Sagar Pandit",
        country: "Vedic, Numerology, Palmist",
        population: "7 Years",
        image:
            "https://www.citrix.com/blogs/wp-content/upload/2018/03/slack_compressed-e1521621363404-360x360.jpg"));

    lstOfCities.add(City(
        name: "Sagar Pandit",
        country: "Vedic, Numerology, Palmist",
        population: "7 Years",
        image:
            "https://www.citrix.com/blogs/wp-content/upload/2018/03/slack_compressed-e1521621363404-360x360.jpg"));

    lstOfCities.add(City(
        name: "Ashok",
        country: "Vedic",
        population: "19 Years",
        image:
            "https://www.pngfind.com/pngs/m/610-6104451_image-placeholder-png-user-profile-placeholder-image-png.png"));

    return lstOfCities;
  }
}
