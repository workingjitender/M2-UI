import 'package:astro_app/constants.dart';
import 'package:flutter/material.dart';

import '../../models/bill_model.dart';

import '../common/appBar.dart';
import '../common/side_navigation.dart';
import '../pages/chat_intake_form.dart';
import 'home/components/categories.dart';

class ViewAstroCall extends StatefulWidget {
  final String title;
  const ViewAstroCall({super.key, required this.title});

  @override
  State<ViewAstroCall> createState() => _ViewAstroCallState();
}

class _ViewAstroCallState extends State<ViewAstroCall> {
  final List<City> _allCities = City.allCities();
  final billsListKey = GlobalKey<_ViewAstroCallState>();
  TextEditingController controller = TextEditingController();
  String searchString = "";

  @override
  void initState() {
    super.initState();
  }

  getHomePageBody(BuildContext context) {
    return ListView.builder(
      itemCount: _allCities.length,
      itemBuilder: _getItemUI,
      padding: EdgeInsets.all(0.0),
    );
  }

  Widget _getItemUI(BuildContext context, int index) {
    return Card(
        child: Column(
      children: <Widget>[
        ListTile(
          contentPadding: const EdgeInsets.all(5),
          leading: CircleAvatar(
            backgroundImage: NetworkImage(
              _allCities[index].image,
              scale: 2,
            ),
            minRadius: 40,
            maxRadius: 50,
          ),

          title: Text(
            _allCities[index].name,
            style: const TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold),
          ),

          subtitle: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(_allCities[index].country,
                    style: TextStyle(
                        fontSize: 13.0, fontWeight: FontWeight.normal)),
                Text('Exp : ${_allCities[index].population}',
                    style: TextStyle(
                        fontSize: 11.0, fontWeight: FontWeight.normal)),
              ]),
          //trailing: ,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const ChatIntakeForm()),
            );
          },
        )
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: billsListKey,
      appBar: BaseAppBar(
        title: Text(
          widget.title,
          style: Styles().appbarStyle,
        ),
        appBar: AppBar(),
      ),
      drawer: const SideNavigation(),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: Column(
          children: <Widget>[
            const SizedBox(
              height: 15,
            ),
            const Categories(),
            SizedBox(
                height: MediaQuery.of(context).size.height * 0.69,
                child: getHomePageBody(context)),
          ],
        ),
      ),
    );
    // ignore: dead_code
  }
}
