import 'package:astro_app/constants.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icon.dart';

class Categories extends StatelessWidget {
  const Categories({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CategoryCard(
              icon: LineIcon.list(
                size: 16,
                color: Colors.white,
              ),
              press: () {
                const snackBar = SnackBar(
                  content: Text('Clicked'),
                );
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
              },
              text: 'All',
              color: Styles().darkblueColor,
            ),
            CategoryCard(
              icon: LineIcon.heart(
                size: 16,
                color: Colors.white,
              ),
              press: () {
                const snackBar = SnackBar(
                  content: Text('Clicked'),
                );
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
              },
              text: 'Love',
              color: Styles().tabdarkredColor,
            ),
            CategoryCard(
              icon: LineIcon.graduationCap(
                size: 16,
                color: Colors.white,
              ),
              press: () {
                const snackBar = SnackBar(
                  content: Text('Clicked'),
                );
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
              },
              text: 'Education',
              color: Styles().tabpinkColor,
            ),
            CategoryCard(
              icon: LineIcon.suitcase(
                size: 16,
                color: Colors.white,
              ),
              press: () {
                const snackBar = SnackBar(
                  content: Text('Clicked'),
                );
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
              },
              text: 'Career',
              color: Styles().blueColor,
            ),
            CategoryCard(
              icon: LineIcon.medicalClinic(
                size: 16,
                color: Colors.white,
              ),
              press: () {
                const snackBar = SnackBar(
                  content: Text('Clicked'),
                );
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
              },
              text: 'Health',
              color: Styles().tabOrangeColor,
            ),
            CategoryCard(
              icon: LineIcon.wallet(
                size: 16,
                color: Colors.white,
              ),
              press: () {
                const snackBar = SnackBar(
                  content: Text('Clicked'),
                );
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
              },
              text: 'Wealth',
              color: Styles().goldColor,
            ),
            CategoryCard(
              icon: LineIcon.building(
                size: 16,
                color: Colors.white,
              ),
              press: () {
                const snackBar = SnackBar(
                  content: Text('Clicked'),
                );
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
              },
              text: 'Business',
              color: Styles().tabJamunColor,
            ),
          ],
        ),
      ),
    );
  }
}

class CategoryCard extends StatelessWidget {
  const CategoryCard({
    Key? key,
    required this.icon,
    required this.text,
    required this.press,
    required this.color,
  }) : super(key: key);

  final String text;
  final Icon icon;
  final Color color;

  final GestureTapCallback press;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: press,
      child: SizedBox(
        //width: 100,
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(12, 5, 12, 5),
              margin: const EdgeInsets.fromLTRB(0, 0, 10, 0),
              // height: 40,
              //width: 80,
              decoration: BoxDecoration(
                color: color,
                border: Border.all(
                  color: color,
                  width: 2,
                ),
                borderRadius: BorderRadius.circular(
                  50,
                ),
              ),
              child: Row(
                children: <Widget>[
                  icon,
                  const SizedBox(
                    width: 4,
                  ),
                  Text(
                    text,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: headFont,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
