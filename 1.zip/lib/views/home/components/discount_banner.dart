import 'package:astro_app/constants.dart';
import 'package:flutter/material.dart';

class DailyHoroscopeView extends StatelessWidget {
  const DailyHoroscopeView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: 90,
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(20, 20, 20, 10),
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 15,
      ),
      decoration: BoxDecoration(
        image: const DecorationImage(
          image: AssetImage("assets/images/horoscope_banner.jpg"),
          fit: BoxFit.cover,
        ),
        color: kPrimaryColor,
        borderRadius: BorderRadius.circular(5),
      ),
      child: const Text.rich(
        TextSpan(
          style: TextStyle(color: Colors.white),
          children: [
            TextSpan(
              text: "Your Daily\n",
              style: TextStyle(
                fontSize: 18,
                fontFamily: headFont,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextSpan(
              text: "Horoscope",
              style: TextStyle(
                fontSize: 24,
                fontFamily: headFont,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
