import 'package:flutter/material.dart';
import '../../common/appBar.dart';
import '../../common/coustom_bottom_nav_bar.dart';
import '../../common/side_navigation.dart';
import '../../constants.dart';
import '../../enums.dart';

import 'components/body.dart';

class HomeView extends StatefulWidget {
  final String title;
  const HomeView({super.key, required this.title});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: BaseAppBar(
        title: Text(
          widget.title,
          style: Styles().appbarStyle,
        ),
        appBar: AppBar(),
      ),
      drawer: const SideNavigation(),
      body: const Body(),
    );
  }
}
